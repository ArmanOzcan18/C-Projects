# frozen_string_literal: true
##
# For RubyGems backwards compatibility

module RDoc::RI::Formatter # :nodoc:
end
